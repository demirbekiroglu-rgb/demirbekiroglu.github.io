import SwiftUI

struct ContentView: View {
    
    
    
    let choices = ["🤛", "🫳", "✌️"]
    
    @State private var userChoice = ""
    @State private var computerChoice = ""
    @State private var result = "Make your move!"
    
    
    
    func randomComputerChoice() -> String {
        return choices.randomElement() ?? "🤛"
    }
    
    func determineWinner(user: String, computer: String) -> String {
        
        if user == computer {
            return "It's a tie!"
        }
        
    
        if (user == "🤛" && computer == "✌️") ||
            (user == "🫳" && computer == "🤛") ||
            (user == "✌️" && computer == "🫳") {
            return "You win!"
        } else {
            return "You lose!"
        }
    }
    
    
    
    var body: some View {
        VStack(spacing: 20) {
            
            Text("Rock Paper Scissors")
                .font(.largeTitle)
                .bold()
            
            Text("Computer: \(computerChoice)")
                .font(.title2)
            
            Text(result)
                .font(.title3)
            
            HStack(spacing: 30) {
                ForEach(choices, id: \.self) { choice in
                    Button(choice) {
                        userChoice = choice
                        computerChoice = randomComputerChoice()
                        result = determineWinner(user: userChoice, computer: computerChoice)
                    }
                    .font(.system(size: 50))
                }
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}


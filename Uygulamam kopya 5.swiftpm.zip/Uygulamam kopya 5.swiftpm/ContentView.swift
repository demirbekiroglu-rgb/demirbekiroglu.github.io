import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            
            Rectangle()
                .frame(width:80, height:200)
                .offset(y: 200)
            
            Capsule()
                .frame(width: 250, height: 300)
                .foregroundStyle(Color.brown)
            RoundedRectangle(cornerRadius: 70)
                .foregroundStyle(.indigo)
                .frame(width: 500, height:600)
                .offset(y:550)
            
            
            Circle()
                .trim(from:0.5, to: 1.0)
                .frame(width:275)
            Circle()
                .trim(from:0.5, to: 1.0)
                .frame(width:300)
            Circle()
                .offset(y: 70)
                .frame(width:30)
            Ellipse()
                .frame(width:65, height: 50)
                .offset(x:-55, y:5)
            Ellipse()
                .frame(width:65, height: 50)
                .offset(x:55, y:5)
            Circle()
                .frame(width:30)
                .offset(x:55)
                .foregroundStyle(Color.black)
            Circle()
                .frame(width:30)
                .offset(x:-55)
                .foregroundStyle(Color.black)
            
        }
    }
}
